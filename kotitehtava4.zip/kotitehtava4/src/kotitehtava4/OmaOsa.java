package kotitehtava4;

//peri Osa-luokka ja toteuta sen abstraktit metodit ja lisää
//tarvittavat attribuutit
public class OmaOsa {
	//valmistusraaka-aineen yksikköhinta ja sitä tarvittava määrä
	//attribuutit privateiksi

	
	//toteuta puuttuvat metodit, jotka abstrakteja kantaluokassa, jonk perit tälle luokalle
	
	//...
	
	//....
}
