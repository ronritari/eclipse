package kotitehtava4;

public class OstettuOsa {
	//toimittajayrityksen nimi ja osan hinta
	//privatena attribuutteina
}
