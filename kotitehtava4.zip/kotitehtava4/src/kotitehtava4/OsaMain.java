package kotitehtava4;

public class OsaMain {
	//määritellään yksi yhteinen ArrayList-kokoelma kaikille varastossa oleville osille
	//siis private ja tyyppiä Osa
	public static void main(String[] args) {
		// luodaan muutama koneenosaolio kokoelmaan
		
		//käydään kokoelmassa olevat oliot läpi tulostaen kunkin tiedot
		//https://beginnersbook.com/2013/12/how-to-loop-arraylist-in-java/
		//kutsu osan toString
		
		//käydään kokoelmassa olevat oliot läpi tulostaen kullekin nimi ja varaston arvon
		//osa voi olla siis oma osa tai ostettuosa ja molemmat laskevat getVarastonArvon() eri tavalla

	}

}
