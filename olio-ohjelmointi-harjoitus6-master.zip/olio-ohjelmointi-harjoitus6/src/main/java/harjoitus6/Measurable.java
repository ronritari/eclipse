package harjoitus6;

public interface Measurable {
//TODO
}
