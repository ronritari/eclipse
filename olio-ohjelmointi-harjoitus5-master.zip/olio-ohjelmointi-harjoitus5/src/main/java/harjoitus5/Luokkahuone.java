package harjoitus5;

public class Luokkahuone extends Huone{
//tuolit, tietokoneet, videotykki
//metodi kysyTiedot()
}
