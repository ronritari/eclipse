package harjoitus5;

public class CustomerMain {

	public static void main(String[] args) {
		/* Kirjoita main-metodi, jossa on yksi ArrayList-kokoelma kaikille
		asiakastiedoille. Luo sinne muutama asiakasolio, joista osa edustaa
		tavallista asiakasta ja osa etuasikasta. Käy kokoelma läpi ja tulosta
		kaikkien asiakkaiden tiedot. Käy kokoelma läpi ja tulosta etuasiakkaiden
		tiedot ja kertynyt bonus. (Ei tarvitse kysyä tietoja käyttäjältä.)*/
		
		//asiakasArray.add(new PreferredCustomer(....))
		
		//for(Customer c: asiakasArray){...}

	}

}
