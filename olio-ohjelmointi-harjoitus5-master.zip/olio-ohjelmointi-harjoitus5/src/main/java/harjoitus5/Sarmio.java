package harjoitus5;

public class Sarmio {
	public static double leveys, korkeus, pituus;
	
	public static double tilavuus() {
		return leveys*korkeus*pituus;
	}

}

