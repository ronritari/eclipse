package harjoitus5;

//lisää piriminen luokasta Sarmio
public class UmpiSarmio{
	//lisää attribuutti tiheys doublena
	//lisää getterit ja setterit getTiheys(), setTiheys(in double)
	//toteuta metodi public double massa()	
	//toteuta main, jossa testaat syöttää särmiön mitat ja tiheyden ja tulostat massan

}
