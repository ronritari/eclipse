package harjoitus5;

import java.util.ArrayList;

//peri luokasta Customer
public class PreferredCustomer {
	//lisää purchases
	//tee purchases attribuutille setterit ja getterit

	//toteuta metodi calculateBonus(), joka palauttaa doublen
	//Jos ostot ovat 500 – 1000 (tuhat mukaanlukien), niin bonusta kertyy 2 % ostojen
	//määrästä, ja jos ostot ovat yli 1000, niin bonus on 5 % ostojen määrästä.

	//add customers ArrayList

	//method setCustomers to add arraylist of customers 

	//method listCustomers to return all customers in string
	
	//method listCustomers to return preferred customers in string

	//toString
}
