package harjoitus5;

//peri luokalta Huone
public class Tyohuone extends Huone{
	//merkkijono henkilöistä
	//metodi kysyTiedot()

}
