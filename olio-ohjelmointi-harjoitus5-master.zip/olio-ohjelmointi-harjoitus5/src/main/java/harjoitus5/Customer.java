package harjoitus5;

public class Customer {
	//lisää attribuutit, konstruktori ja getterit ja setterit ja toString
	//number int

	//name, address String
	//tee attribuuteille setterit ja geetterit

}
