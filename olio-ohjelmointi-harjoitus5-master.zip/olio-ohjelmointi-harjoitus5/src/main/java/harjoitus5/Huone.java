package harjoitus5;

public class Huone {
	//lisää attribuutit tunnus ja kuvaus

}
