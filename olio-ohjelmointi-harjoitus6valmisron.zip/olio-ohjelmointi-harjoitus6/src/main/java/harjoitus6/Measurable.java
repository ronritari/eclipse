package harjoitus6;

public interface Measurable {
//TODO
	public double area();
	
	
	public double perimeter();
	
	
	public void scale(double scaleValue); 
}
